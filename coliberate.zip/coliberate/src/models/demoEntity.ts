export interface DemoEntity {
  timestamp: number,
  value: string
}
