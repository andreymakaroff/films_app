import * as React from 'react'
import { withRouter, RouteComponentProps } from 'react-router'
import { ListItem, ListItemIcon, ListItemText, Divider } from '@material-ui/core'
import { withStyles, WithStyles } from '@material-ui/core/styles'
// import DemoEntityIcon from '@material-ui/icons/Star'
import DemoRoutinesIcon from '@material-ui/icons/Refresh'
import BuildConfigIcon from '@material-ui/icons/Settings'
import { compose } from 'recompose'
import { Routes } from '../App'
import styles, { classes } from './styles'

type ComponentProps = RouteComponentProps<undefined> & WithStyles<classes>

interface ComponentState {
}

class PrimaryNav extends React.Component<ComponentProps, ComponentState> {
  navigateToRegistration = () => this.props.history.push(Routes.Registration)
  // navigateToDemoEntities = () => this.props.history.push(Routes.DemoEntities)
  navigateToDemoRoutines = () => this.props.history.push(Routes.DemoRoutines)

  render () {
    const { classes } = this.props

    return (
      <div className={classes.root}>
        <div className={classes.header} />
        <nav className={classes.menu}>
          <Divider />
          <>
            <ListItem button onClick={this.navigateToRegistration}>
              <ListItemIcon>
                <BuildConfigIcon />
              </ListItemIcon>
              <ListItemText primary={'Registration'} />
            </ListItem>
          </>
          <Divider />
          <>
            {/*<ListItem button onClick={this.navigateToDemoEntities}>*/}
              {/*<ListItemIcon>*/}
                {/*<DemoEntityIcon />*/}
              {/*</ListItemIcon>*/}
              {/*<ListItemText primary={'Demo Entities'} />*/}
            {/*</ListItem>*/}
            <ListItem button onClick={this.navigateToDemoRoutines}>
              <ListItemIcon>
                <DemoRoutinesIcon />
              </ListItemIcon>
              <ListItemText primary={'Demo Routines'} />
            </ListItem>
          </>
        </nav>
      </div>
    )
  }
}

export default compose(
  withRouter,
  withStyles(styles, { withTheme: true })
)(PrimaryNav)
