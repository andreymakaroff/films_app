import * as React from 'react'
import { Dispatch, AnyAction } from 'redux'
import { connect } from 'react-redux'
import { Action } from 'redux-actions'
import { Typography, Paper, Button, Table, TableHead, TableBody, TableRow, TableCell } from '@material-ui/core'
import { withStyles, WithStyles } from '@material-ui/core/styles'
import { compose } from 'recompose'
import { demoRoutineOneAction, demoRoutineTwoAction } from '../../actions'
import { State } from '../../reducers'
import styles, { classes } from './styles'

interface ComponentsPropsFromDispatch {
  runDemoRoutineOne: (delay: number) => void,
  runDemoRoutineTwo: (delay: number) => void
}

interface ComponentsPropsFromState {
  count: number,
  recentResults: Action<any>[]
}

type ComponentProps = ComponentsPropsFromDispatch & ComponentsPropsFromState & WithStyles<classes>

interface ComponentState {
}

class DemoRoutines extends React.Component<ComponentProps, ComponentState> {
  static mapStateToProps (state: State): ComponentsPropsFromState {
    return {
      count: state.demoRoutines.count,
      recentResults: state.demoRoutines.recentResults.slice()
    }
  }

  static mapDispatchToProps (dispatch: Dispatch<AnyAction>): ComponentsPropsFromDispatch {
    return {
      runDemoRoutineOne: (delay: number) => dispatch(demoRoutineOneAction({ delay })),
      runDemoRoutineTwo: (delay: number) => dispatch(demoRoutineTwoAction({ delay }))
    }
  }

  runOneForOneSecond = () => this.props.runDemoRoutineOne(1000)
  runOneForFiveSeconds = () => this.props.runDemoRoutineOne(5000)
  runOneForFifteenSeconds = () => this.props.runDemoRoutineOne(15000)
  runTwoForOneSecond = () => this.props.runDemoRoutineTwo(1000)
  runTwoForFiveSeconds = () => this.props.runDemoRoutineTwo(5000)
  runTwoForFifteenSeconds = () => this.props.runDemoRoutineTwo(15000)

  render () {
    const { classes } = this.props

    return (
      <div className={classes.root}>
        <Paper className={classes.box}>
          <Typography className={classes.title} color={'inherit'} variant={'headline'}>
            Demo Routines
          </Typography>
          <Button className={classes.button} onClick={this.runOneForOneSecond}>Run One for 1 second</Button>
          <Button className={classes.button} onClick={this.runOneForFiveSeconds}>Run One for 5 seconds</Button>
          <Button className={classes.button} onClick={this.runOneForFifteenSeconds}>Run One for 15 seconds</Button>
          <Button className={classes.button} onClick={this.runTwoForOneSecond}>Run Two for 1 second</Button>
          <Button className={classes.button} onClick={this.runTwoForFiveSeconds}>Run Two for 5 seconds</Button>
          <Button className={classes.button} onClick={this.runTwoForFifteenSeconds}>Run Two for 15 seconds</Button>
        </Paper>
        <Paper className={classes.box}>
          <Typography className={classes.title} color={'inherit'} variant={'headline'}>
            Recent Results ({this.props.count} pending)
          </Typography>
          <Table className={classes.recentResultsTable}>
            <TableHead>
              <TableRow>
                <TableCell>Routine</TableCell>
                <TableCell>Result</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {this.props.recentResults.map((recentResult, index) => {
                return (
                  <TableRow key={index}>
                    <TableCell>{recentResult.type.split('/')[0]}</TableCell>
                    <TableCell>{recentResult.payload ? (<pre>{JSON.stringify(recentResult.payload)}</pre>) : (<i>undefined</i>)}</TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </Paper>
      </div>
    )
  }
}

export default compose(
  connect(DemoRoutines.mapStateToProps, DemoRoutines.mapDispatchToProps),
  withStyles(styles, { withTheme: true })
)(DemoRoutines)
