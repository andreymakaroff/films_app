import * as React from 'react'
import CreateForm from './CreateForm'

export default class Registration extends React.Component {

  render () {
    return (
      <div>
          <CreateForm/>
      </div>
    )
  }
}
