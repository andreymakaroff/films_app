import * as _ from 'lodash'
import { Action } from 'redux-actions'
import { takeEvery, put, call } from 'redux-saga/effects'
import { createRoutine, ReduxFormPayload } from 'redux-saga-routines'
import { DemoEntity } from '../models/demoEntity'

export interface FormValues {
  value: string
}

export type Payload = ReduxFormPayload<FormValues>

export const action = createRoutine<Payload, Payload>('CREATE_DEMO_ENTITY', _.identity)

async function signUp (value: string): Promise<DemoEntity> {
  // NOTE: Here should've been a call to API
  return {
    timestamp: Date.now(),
    value
  }
}

function* handler ({ payload }: Action<any>) {
  try {
    yield put(action.request())
    const instance = yield call(signUp, payload.values.value)
    yield put(action.success({ instance }))
  } catch (error) {
    yield put(action.failure(error.message))
  } finally {
    yield put(action.fulfill())
  }
}

export function * saga () {
  yield takeEvery(action.TRIGGER, handler)
}
